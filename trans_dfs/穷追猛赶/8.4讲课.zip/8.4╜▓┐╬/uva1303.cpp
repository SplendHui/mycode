
#include <cstdio>
#include <cmath>
#include <algorithm>
using namespace std;

const double PI = acos(-1);

struct Point
{
    double x, y;
    Point() {}
    Point(double xx, double yy) : x(xx), y(yy) {}
};

typedef Point Vector;

Vector operator - (Vector a, Vector b) { return Vector(a.x - b.x, a.y - b.y); }

bool operator < (const Point& a, const Point& b)
{
    return a.x < b.x || (a.x == b.x && a.y < b.y);
}

double Dot(Vector a, Vector b) { return a.x * b.x + a.y * b.y; }
double Length(Vector a) { return sqrt(a.x * a.x + a.y * a.y); }
double Angle(Vector a, Vector b) { return acos(Dot(a, b) / Length(a) / Length(b)); }
double Cross(Vector a, Vector b) { return a.x * b.y - a.y * b.x; }

int ConvexHull(Point* p, int n, Point* ch)
{
    sort(p, p + n);
    int m = 0;
    for(int i = 0; i < n; i++)
    {
        while(m > 1 && Cross(ch[m - 1] - ch[m - 2], p[i] - ch[m - 2]) <= 0) m--;
        ch[m++] = p[i];
    }
    int k = m;
    for(int i = n - 2; i >= 0; i--)
    {
        while(m - k && Cross(ch[m -1] - ch[m - 2], p[i] - ch[m - 2]) <= 0) m--;
        ch[m++] = p[i];
    }
    //if(n > 1) m--;

    return m;
}

const int maxn = 1000 + 10;
Point p[maxn], ch[maxn];
int main()
{
    int t;
    scanf("%d", &t);
    while(t--)
    {
        int n, l;
        scanf("%d%d", &n, &l);
        for(int i = 0; i < n; i++) scanf("%lf%lf", &p[i].x, &p[i].y);

        int m = ConvexHull(p, n, ch);
        double ans = 0;
        for(int i = 1; i < m; i++)
        {
            ans += Length(ch[i] - ch[i - 1]);
        }
        ans += 2 * PI * l;
        printf("%.0lf\n", ans);
        if(t) printf("\n");
    }
    return 0;
}