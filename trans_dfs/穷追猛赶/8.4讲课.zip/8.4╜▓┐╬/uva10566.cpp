#include "cstdio"
#include "cmath"
#include "iostream"
using namespace std;
double x,y,c;
double getans(double w)
{
	return 1-c/sqrt(x*x-w*w)-c/sqrt(y*y-w*w);
	
}
int main()
{
	while(~scanf("%lf%lf%lf",&x,&y,&c))
	{
		double l=0,r=min(x,y);
		double mid=l+(r-l)*0.5;
		while(r-l>1e-8)
		{
			mid=l+(r-l)/2;
			if(getans(mid)>0)
			l=mid;
			else
			r=mid;	
		}
		printf("%.3lf\n",mid);
		
	}
	return 0;
}