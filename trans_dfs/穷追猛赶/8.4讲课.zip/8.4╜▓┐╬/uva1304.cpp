#include <iostream>
#include <cstdio>
#include <string.h>
#include <math.h>
#include <string>
#include <cstring>
#include <map>
#include <algorithm>
#include <vector>
using namespace std;
#define eps 1e-10
const double inf = 1e16;
const double PI = acos(-1.0);

struct Point{
	Point(const Point &p) { x = p.x, y = p.y; }
	Point(double xx = 0, double yy = 0) : x(xx), y(yy) { }
	double x;
	double y;
};

typedef Point Vector;
Vector operator+(Vector  v1, Vector  v2) { return Vector(v1.x + v2.x, v1.y + v2.y); }
Vector operator-(Vector  v1, Vector  v2) { return Vector(v1.x - v2.x, v1.y - v2.y); }
Vector operator*(Vector  v, double p) { return Vector(v.x * p, v.y * p); }
Vector operator/(Vector  v, double p) { return Vector(v.x / p, v.y / p); }

bool operator < (Point  a, Point  b) { return a.x < b.x || (a.x == b.x && a.y > b.y); }
int dcmp(double x) {
	if (fabs(x) < eps) return 0;
	return x < 0 ? -1 : 1;
}
bool operator==(const Point &a, const Point &b) {
	return dcmp(a.x - b.x) == 0 && dcmp(a.y - b.y) == 0;
}

inline double toRad(double x) { return x * PI / 180; }
inline double toDegreed(double rad) { return rad * 180 / PI; }
double Dot(Vector  A, Vector  B) { return A.x * B.x + A.y * B.y; }
double Length(Vector  A) { return sqrt(Dot(A, A)); }
double Angle(Vector A, Vector B) { return acos(Dot(A, B) / Length(A) / Length(B)); }
double Cross(Vector A, Vector B) { return A.x * B.y - A.y * B.x; }
double Area2(Point a, Point b, Point c) { return fabs(Cross(b - a, c - a)); }

//��ת 

Vector Rotate(Vector A, double rad){
	return Vector(A.x * cos(rad) - A.y * sin(rad), A.x * sin(rad) + A.y * cos(rad));
}

//��λ���� 

Vector Normal(Vector A) { double L = Length(A); return Vector(-A.y / L, A.x / L); }

//���ֱ��

Point GetLineIntersection(Point P, Vector v, Point Q, Vector w){
	Vector u = P - Q;
	double t = Cross(w, u) / Cross(v, w);
	return P + v * t;
}

double DistanceToLine(Point P, Point A, Point B) {
	Vector v1 = B - A, v2 = P - A;
	return fabs(Cross(v1, v2)) / Length(v1);
}

double DistanceToSegment(Point P, Point A, Point B){
	if (A == B) return Length(P - A);
	Vector v1 = B - A, v2 = P - A, v3 = P - B;
	if (dcmp(Dot(v1, v2)) < 0) return Length(v2);
	else if (dcmp(Dot(v1, v3)) > 0) return Length(v3);
	else return fabs(Cross(v1, v2)) / Length(v1);
}

//����ֱ���ϵ�ͶӰ

Point GetLineProjection(Point P, Point A, Point B) {
	Vector v = B - A;
	return A + v * (Dot(v, P - A) / Dot(v, v));
}

//�߶��ཻ(�������˵㣩

bool SegmentProperIntersection(Point a1, Point a2, Point b1, Point b2) {
	double c1 = Cross(a2 - a1, b1 - a1), c2 = Cross(a2 - a1, b2 - a1),
		c3 = Cross(b2 - b1, a1 - b1), c4 = Cross(b2 - b1, a2 - b1);
	return dcmp(c1)*dcmp(c2) < 0 && dcmp(c3)*dcmp(c4) < 0;
}

//�����߶��ϣ��������˵㣩

bool OnSegment(Point p, Point a, Point b){
	return dcmp(Cross(a - p, b - p)) == 0 && dcmp(Dot(a - p, b - p)) < 0;
}

//�߶��ཻ�������˵㣩

bool SegmentIntersection(Point a1, Point a2, Point b1, Point b2) {
	if (SegmentProperIntersection(a1, a2, b1, b2)) return true;
	if (OnSegment(a1, b1, b2) || OnSegment(a2, b1, b2)) return true;
	if (OnSegment(b1, a1, a2) || OnSegment(b2, a1, a2)) return true;
	if (a1 == b1 || a1 == b2 || a2 == b1 || a2 == b2) return true;
	return false;
}

//--------------------------------------------------------------------------------------------

//ֱ�ߺ�ֱ��


struct Line{
	Point P;				//ֱ��������һ��

	Vector v;				// ����ʸ����������߾��Ƕ�Ӧ�İ�ƽ��

	double ang;			//����

	Line() { }
	Line(Point P, Vector v) { this->P = P; this->v = v; ang = atan2(v.y, v.x); }
	bool operator < (const Line& L) const { return ang < L.ang; } //�����õıȽ������


	Point point(double t) { return v * t + P; }
};

//��p������ֱ��L����ߣ����߲��㣩

bool OnLeft(Line L, Point p) { return Cross(L.v, p - L.P) > 0; }

//��ֱ�߽��㡣�ٶ�����Ψһ����

Point GetIntersection(Line a, Line b) {
	Vector u = a.P - b.P;
	double t = Cross(b.v, u) / Cross(a.v, b.v);
	return a.P + a.v*t;
}

//��ƽ�潻���

double PolyArea(Point *poly, int n) { 
	double ret = 0; 
	for (int i = 1; i < n - 1; ++i) 
		ret += Cross(poly[i] - poly[0], poly[i + 1] - poly[0]); 
	return ret / 2; 
}

//��ƽ�潻�Ĺ���

int HalfplaneIntersection(Line* L, int n, Point* poly){
	sort(L, L + n);						     //����������

	int first, last;						//˫�˶��еĵ�һ��Ԫ�غ����һ��Ԫ�ص��±�

	Point *p = new Point[n];		//p[i]Ϊq[i]��q[i+1]�Ľ���

	Line *q = new Line[n];			//˫�˶���

	q[first = last = 0] = L[0];			//˫�˶��г�ʼ��Ϊֻ��һ����ƽ��L[0]

	for (int i = 1; i < n; i++) {
		while (first < last && !OnLeft(L[i], p[last - 1])) last--;
		while (first < last && !OnLeft(L[i], p[first])) first++;
		q[++last] = L[i];
		if (fabs(Cross(q[last].v, q[last - 1].v)) < eps) {
			last--;
			if (OnLeft(q[last], L[i].P)) q[last] = L[i];
		}
		if (first < last) p[last - 1] = GetIntersection(q[last - 1], q[last]);
	}
	while (first < last && !OnLeft(q[first], p[last - 1])) last--;
	//ɾ������ƽ�棨*��

	if (last - first <= 1) return 0;                    //�ռ�(**)

	p[last] = GetIntersection(q[last], q[first]);		//������β������ƽ��Ľ���

	//��deque���Ƶ������

	int m = 0;
	for (int i = first; i <= last; i++) poly[m++] = p[i];
	return m;
}

//--------------------------------------------

//��Բ���


struct Circle {
	Circle() { }
	Point c;
	double r;
	Circle(Point c, double r) : c(c), r(r) { }
	Point point(double a) { return Point(c.x + cos(a)*r, c.y + sin(a)*r); }
};

int getLineCircleIntersection(Line L, Circle C, double &t1, double &t2, vector<Point>& sol){
	double a = L.v.x, b = L.P.x - C.c.x, c = L.v.y, d = L.P.y - C.c.y;
	double e = a*a + c*c, f = 2 * (a*b + c*d), g = b*b + d*d - C.r*C.r;
	double delta = f*f - 4 * e*g;				//�б�ʽ		


	if (dcmp(delta) < 0) return 0;		//����


	if (dcmp(delta) == 0) {                   //���� 


		t1 = t2 = -f / (2 * e);
		sol.push_back(L.point(t1));
		return 1;
	}
	//�ཻ

	t1 = (-f - sqrt(delta)) / (2 * e); sol.push_back(L.point(t1));
	t2 = (-f + sqrt(delta)) / (2 * e); sol.push_back(L.point(t2));
	return 2;
}

double angle(Vector v) { return atan2(v.y, v.x); }

int getCircleCircleIntersection(Circle C1, Circle C2, vector<Point>& sol){
	double d = Length(C1.c - C2.c);
	if (dcmp(d) == 0) {
		if (dcmp(C1.r - C2.r) == 0) return -1;	//��Բ�غ�

		return 0;
	}
	if (dcmp(C1.r + C2.r - d) < 0) return 0;
	if (dcmp(fabs(C1.r - C2.r) - d) > 0) return 0;
	double a = angle(C2.c - C1.c);
	double da = acos((C1.r*C1.r + d*d - C2.r*C2.r) / (2 * C1.r*d));	//ʸ��C1C2�ļ���

	//C1C2��C1P1�Ľ�

	Point p1 = C1.point(a - da), p2 = C1.point(a + da);
	sol.push_back(p1);
	if (p1 == p2) return 1;
	sol.push_back(p2);
	return 2;
}

//����p��ԲC�����ߡ�v[i]�ǵ�i�����ߵ�ʸ����������������


int getTangents(Point p, Circle C, Vector* v){
	Vector u = C.c - p;
	double dist = Length(u);
	if (dist < C.r) return 0;
	else if (dcmp(dist - C.r) == 0) {
		v[0] = Rotate(u, PI / 2);
		return 1;
	}
	else {
		double ang = asin(C.r / dist);
		v[0] = Rotate(u, -ang);
		v[1] = Rotate(u, +ang);
		return 2;
	}
}

int getTangents(Circle A, Circle B, Point* a, Point* b){
	int cnt = 0;
	if (A.r < B.r) { swap(A, B); swap(a, b); }
	double d2 = Dot(A.c - B.c, A.c - B.c);
	double rdiff = A.r - B.r;
	double rsum = A.r + B.r;
	if (dcmp(d2 - rdiff*rdiff) < 0) return 0;	//�ں� 

	double base = atan2(B.c.y - A.c.y, B.c.x - A.c.x);
	if (d2 == 0 && dcmp(A.r - B.r) == 0) return -1;	//���޶������� 

	if (dcmp(d2 - rdiff*rdiff) == 0) {		//���У�1������ 

		a[cnt] = A.point(base);
		b[cnt] = B.point(base);
		cnt++;
		return 1;
	}
	//�����й���

	double ang = acos((A.r - B.r) / sqrt(d2));
	a[cnt] = A.point(base + ang); b[cnt] = B.point(base + ang); cnt++;
	a[cnt] = A.point(base - ang); b[cnt] = B.point(base - ang); cnt++;
	if (dcmp(d2 - rsum*rsum) == 0) {		//һ���ڹ����� 

		a[cnt] = A.point(base);
		b[cnt] = B.point(PI + base);
		cnt++;
	}
	else if (dcmp(d2 - rsum*rsum) > 0) {		//���������� 

		double ang = acos((A.r + B.r) / sqrt(d2));
		a[cnt] = A.point(base + ang); b[cnt] = B.point(PI + base + ang); cnt++;
		a[cnt] = A.point(base - ang); b[cnt] = B.point(PI + base - ang); cnt++;
	}
	return cnt;
}

//��p��Բ�Ĺ�ϵ: 0:��Բ�� 1����Բ�� -1����Բ�� 


int PointCircleRelation(Point p, Circle c) {
	return dcmp(Dot(p - c.c, p - c.c) - c.r*c.r);
}

//A��B�� 

bool InCircle(Circle A, Circle B){
	if (dcmp(A.r - B.r) > 0) return false;
	double d2 = Dot(A.c - B.c, A.c - B.c);
	double rdiff = A.r - B.r;
	double rsum = A.r + B.r;
	if (dcmp(d2 - rdiff*rdiff) <= 0) return true;			//�ں������л��غ� 

	return false;
}
//----------------------------------------------------------------------------

//������ص�ת�� 


//�Ƕ�ת��Ϊ���� 

double torad(double deg) { return deg / 180 * PI; }

//��γ�ȣ��Ƕȣ�ת��Ϊ�ռ����� 

void get_coord(double R, double lat, double lng, double& x, double& y, double& z){
	lat = torad(lat);
	lng = torad(lng);
	x = R*cos(lat)*cos(lng);
	y = R*cos(lat)*sin(lng);
	z = R*sin(lat);
}

//-----------------------------------------------------------------------

//�����㷨��

const int MAXN = 1505;
int n;
Point p[MAXN], Poly[MAXN];
Line L[MAXN];

int main(){
	int T,m;
	scanf("%d", &T);
	while (T--) {
		scanf("%d", &n);
		for (int i = 0; i < n; i++){
			scanf("%lf%lf", &p[i].x, &p[i].y);
		}
		for (int i = 0; i < n; i++){
			L[i] = Line(p[(i + 1) % n], p[i] - p[(i + 1) % n]);
		}
		m=HalfplaneIntersection(L, n, Poly);
		printf("%.2lf\n", PolyArea(Poly, m) + eps);		
	}
}