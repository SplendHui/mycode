#include <cstdio>
#include <cstring>
#include <cmath>
#include <vector>
#include <algorithm>
using namespace std;

const double PI = acos(-1);

struct Point
{
    double x, y;
    Point() {}
    Point(double xx, double yy) : x(xx), y(yy) {}
};

typedef Point Vector;

Vector operator + (Vector a, Vector b) { return Vector(a.x + b.x, a.y + b.y); }
Vector operator - (Vector a, Vector b) { return Vector(a.x - b.x, a.y - b.y); }
Vector operator * (Vector a, double p) { return Vector(a.x * p, a.y * p); }

double eps = 1e-12;
int dcmp(double x)
{
    if(fabs(x) < eps) return 0;
    return x < 0 ? -1 : 1;
}

double Length(Vector a) { return sqrt(a.x * a.x + a.y * a.y); }

double angle(Vector a) { return atan2(a.y, a.x); }
struct Circle
{
    Point c;
    double r;
    Circle() {}
    Circle(Point cc, double rr) : c(cc), r(rr) {}
    Point point(double a)
    {
        return Point(c.x + cos(a) * r, c.y + sin(a) * r);
    }
};


void fun(double& a)
{
    if(a >= 2 * PI) a -= 2 * PI;
    if(a < 0) a += 2 * PI;
}
void getCircleCircleIntersection(Circle A, Circle B, vector<double>& sol)
{
    double d = Length(A.c - B.c);
    if(dcmp(d) == 0) return;
    if(dcmp(A.r + B.r - d) < 0) return;
    if(dcmp(fabs(A.r - B.r) - d) > 0) return;

    double a = angle(B.c - A.c);
    double da = acos((A.r * A.r + d * d - B.r * B.r) / (2 * A.r * d));

    sol.push_back(a - da); sol.push_back(a + da);
}

bool inCircle(Point P, Circle C)
{
    if(Length(P - C.c) < C.r) return true;
    return false;
}

const int maxn = 100 + 10;
bool vis[maxn];
Circle C[maxn];
vector<double> sol;
int main()
{
    int n;
    while(scanf("%d", &n), n)
    {
        memset(vis, 0, sizeof(vis));
        for(int i = 0; i < n; i++) scanf("%lf%lf%lf", &C[i].c.x, &C[i].c.y, &C[i].r);
        for(int i = 0; i < n; i++)
        {
            sol.clear();
            sol.push_back(0); sol.push_back(2 * PI);
            for(int j = 0; j < n; j++) if(j != i)
            {
                getCircleCircleIntersection(C[i], C[j], sol);
            }
            sort(sol.begin(), sol.end());
            for(int j = 1; j < sol.size(); j++)
            {
                Point p = C[i].point((sol[j - 1] + sol[j]) * 0.5);
                Vector v = (C[i].c - p) * eps;
                Point p1 = p + v;
                Point p2 = p - v;
                for(int k = n - 1; k >= 0; k--)
					if(inCircle(p1, C[k]))
	                {
	                    vis[k] = 1;
	                    break;
	                }
                for(int k = n - 1; k >= 0; k--) 
					if(inCircle(p2, C[k]))
                	{
                    	vis[k] = 1;
                    	break;
               		}
            }
        }
        int cnt = 0;
        for(int i = 0; i < n; i++) if(vis[i]) cnt++;
        printf("%d\n", cnt);
    }
    return 0;
}