#include "stdio.h"
struct Dir
{	int row, col;
}dir[4]={{0,1},{1,0},{0,-1},{-1,0}};
int a[1005][1005]={ 0 };
int main()
{	int i,j,n;
//	freopen("square.in", "r", stdin);
//	freopen("square.out", "w", stdout);
	scanf("%d", &n);
//************************************************
	int row=0, col=0, row1, col1,d=0;
	int x=9;
	for( i=0; i<1005; i++)
		for( j=0; j<1005; j++)
			a[i][j]=-1;
	for( i=1; i<=(2*n-1)*(2*n-1); i++)
	{	a[row][col]=x;
		row1=row+dir[d].row;
		col1=col+dir[d].col;
		if( row1<0 || row1>2*n-2 ||
			col1<0 || col1>2*n-2 ||
			a[row1][col1]!=-1 )
		{	d++;
			if( d==4 )
			{	
				x--; 
				if( x<0 ) x=9;
				d=0;
			}
			row1=row+dir[d].row;
			col1=col+dir[d].col;
		}
		row=row1;
		col=col1;
	}
	for( i=0;i<2*n-1; i++)
	{	for( j=0; j<2*n-1; j++)
			printf("%d", a[i][j]);
		printf("\n");
	}
	
//================================================
	return 0;
}