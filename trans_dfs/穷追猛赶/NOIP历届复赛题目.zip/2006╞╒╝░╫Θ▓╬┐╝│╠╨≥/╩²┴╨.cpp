#include <iostream.h>
#include <iomanip.h>
#include <fstream.h>
#define N 20  
int p[N]={0}; 
int k,n;
long res1=0;

void init_seq() 
{int i,n2;
 ifstream myinf("sequence.in",ios::nocreate);
 if(myinf.fail())
    {cerr<<"error opening file myname\n";
     return;
    }
 myinf >>k>>n;
 myinf.close();
 n2=n;
 for(i=0;(i<=11)&&(n2>0);i++)
 {p[i]=n2%2;
  n2=n2/2;
}
}
void out_seq() 
{ofstream myoutf1("sequence.out");
 if(myoutf1.fail())
     {cerr<<"error opening file myname\n";
      return;
     }
 myoutf1 <<res1<<endl;
 myoutf1.close();
 }
void mult()
{int i,j;
 long tmp;
 for(i=0;i<=11;i++)
  if(p[i]==1)
  {tmp=1;
   for(j=1;j<=i;j++)
	tmp=tmp*k;
   res1+=tmp;
  }
}

void main()
{init_seq();
 mult();
 out_seq();
}

