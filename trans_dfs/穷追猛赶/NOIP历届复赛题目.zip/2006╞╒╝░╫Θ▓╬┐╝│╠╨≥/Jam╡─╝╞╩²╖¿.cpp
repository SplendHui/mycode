#include <iostream.h>
#include <fstream.h>
int p[30]={0};
int n,s,t,w;
char str1[30],outstr[6][30];

void init_count() 
{int i;
 ifstream myinf("count.in",ios::nocreate);
 if(myinf.fail())
    {cerr<<"error opening file myname\n";
     return;
    }
 myinf >>s>>t>>w;
 myinf >>str1;
 myinf.close();
 for(i=1;i<=w;i++)
   p[i]=str1[i-1]-96-(s-1);
 n=t-s+1;
}

void out_count() 
{int i;
 ofstream myoutf1("count.out");
 if(myoutf1.fail())
     {cerr<<"error opening file myname\n";
      return;
     }
 for(i=1;i<=5;i++) 
   myoutf1 <<outstr[i]<<endl;
 myoutf1.close();
 }

int comb(int n,int r,int p[])
{int j,k;
 for(j=r;j>=1;j--)
   if (p[j]<n+j-r) 
     {p[j]++;
      for (k=j+1;k<=r;k++)
        p[k]=p[k-1]+1;
      return 1;
      }
 return 0;
}

void main()
{int i,j,j2;
 init_count();
 i=1;
 for(j=1;(j<=5)&&(i>0);j++)
  {i=comb(n,w,p);
   if(i>0) 
    {for(j2=0;j2<w;j2++)
       outstr[j][j2]=p[j2+1]+96+(s-1);      
     outstr[j][w]='\0';
     }
    else
     outstr[j][0]='\0';
   }
 out_count();
}

