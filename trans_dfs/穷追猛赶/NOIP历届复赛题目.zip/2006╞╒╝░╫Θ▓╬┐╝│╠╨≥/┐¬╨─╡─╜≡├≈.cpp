#include <iostream.h>
#include <fstream.h>
#define N 30  
int a[N][3]={0}; //[0]����ţ�[1]���۸�[2]����Ҫ�� 
int nlimit,m; //nlimit����Ǯ����m:����Ʒ��
long tmp[N],best=0,value,allw;

void init_happy() 
{int i;
 ifstream myinf("happy.in",ios::nocreate);
 if(myinf.fail())
    {cerr<<"error opening file myname\n";
     return;
    }
 myinf >>nlimit>>m;
 for(i=1;i<=m;i++)
 {a[i][0]=i;
  myinf >>a[i][1]>>a[i][2];
  tmp[i]=(long)a[i][1]*a[i][2];
 }
 myinf.close();
}

void out_happy() 
{ofstream myoutf1("happy.out");
 if(myoutf1.fail())
     {cerr<<"error opening file myname\n";
      return;
     }
 myoutf1 <<best<<endl;
 myoutf1.close();
 cout <<best<<endl;
 }

void oper1(int k)
{if(k==m+1) 
 {if(value>best)
	  best=value;
  return;
 }
if(allw+a[k][1]<=nlimit)
 {value+=tmp[k];//�ô˼�
  allw+=a[k][1];
  oper1(k+1);
  value-=tmp[k];
  allw-=a[k][1];
 }
 oper1(k+1);//���ô˼�
}
void main()
{init_happy();
 allw=value=0;
 oper1(1);
 out_happy();
}

