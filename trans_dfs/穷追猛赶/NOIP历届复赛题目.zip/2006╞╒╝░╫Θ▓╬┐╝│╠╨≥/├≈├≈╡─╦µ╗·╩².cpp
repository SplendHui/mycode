#include <iostream.h>
#include <fstream.h>
#define N 110  
int a[N],b[N]={0},m,n; 

void init_rand() 
{int i;
 ifstream myinf("random.in",ios::nocreate);
 if(myinf.fail())
    {cerr<<"error opening file myname\n";
     return;
    }
 myinf >>n;
 for(i=1;i<=n;i++)
    myinf >>a[i];
 myinf.close();
}

void result_rand() 
{int i;
 ofstream myoutf1("random.out");
 if(myoutf1.fail())
     {cerr<<"error opening file myname\n";
      return;
     }
 myoutf1 <<m<<endl;
 for(i=1;i<=m;i++)
   {myoutf1 <<b[i]<<" ";
   }
 myoutf1 <<endl; 
 myoutf1.close();
}

void insert() 
{int i,j,j2;
 b[1]=a[1]; m=1;
 for(i=2;i<=n;i++)
 {j=1;
  while(a[i]>b[j] && j<=m) j++;
  if(a[i]!=b[j])
  {for(j2=m;j2>=j;j2--)
     b[j2+1]=b[j2];
   b[j]=a[i]; m++;
  }
 }
}
void main()
{init_rand(); 
 insert(); 
 result_rand(); 
}
